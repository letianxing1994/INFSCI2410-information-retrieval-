a.how long it takes to finish 4 queries
answer: see the screenshot, it takes about 1.2 mins to finish 4 queries

b.retrieval results
answer: please check 4 screenshots with each query(only part of them, because the total number of retrieval result for each query is about 100, it is hard to print all of them unless write into new documents)

c.Java version you used for writing your assignment
answer: jdk 9.0.4, java 1.9.(I think 1.8 is also ok to run my program)

